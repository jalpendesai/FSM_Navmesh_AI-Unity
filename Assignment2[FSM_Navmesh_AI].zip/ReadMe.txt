Updated Assignment 1 by:
-Updating the Maze by adding different Areas to traverse
-Adding Navmesh Obstacles
- Adding Navmesh Areas with different Costs
-Implemented Agents with sense of touch
-Agents can now have Cone of Vision
- Implemented Off mesh Links


Enemies Behaviour:
Enemy 1 : Cannot traverse the UpHills ( He will choose the long path in order to minimize the COST)
Enemy 2: Can traverse All the path (He will choose shortest path and ignore the COST)
Enemy 3: Can traverse the Stairs ( only one ONE direction)
Enemy 4: Cannot traverse DownHills

From this assignment, I got to learn so many new things which will help me in developing my future games.
Thanks
