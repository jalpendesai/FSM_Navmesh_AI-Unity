you can test the asset from the two scenes within the "Extra" Folder.
the asset recieves its input from an input module which is a scriptable object, the input module will be recieved from an input modulator
which is also a scriptable object that will return the current input module for the current platform.

more info can be found at: https://moe-baker.github.io/ARFC/Page.html

also please check out my game framework : https://www.assetstore.unity3d.com/en/#!/content/103060 which has an FPS Template
that integrates with this asset.

Changelog:
v1.2:
-Added Sliding (Sprint & Crouch To Slide).
-Tidied Up The Package (Added API, Cleaned The Test Course, Added Controls Info UI)
v1.1:
-Moved All Controller's Modules Inside The FP Controller Class.